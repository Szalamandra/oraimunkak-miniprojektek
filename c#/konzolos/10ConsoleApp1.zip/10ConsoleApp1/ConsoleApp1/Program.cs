﻿using System;
using System.Text;
using System.IO;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string sor = "";
            string ujsor = "";
            string szoveg = "";
            StreamReader beolvasott = new StreamReader("szoveg.txt");

            while (!beolvasott.EndOfStream)
            {
                sor = Convert.ToString(beolvasott.ReadLine());
                int i = 0;
                while (i < sor.Length)
                {
                    if (Convert.ToChar(sor[i]) != Convert.ToChar(" "))
                    {
                        ujsor = ujsor + sor[i];
                    }
                    i++;
                }
                szoveg = szoveg + ujsor;
                ujsor = "";
            }
            Console.WriteLine(szoveg);
            Console.ReadKey();
        }
    }
}
