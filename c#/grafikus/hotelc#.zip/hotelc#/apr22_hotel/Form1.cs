﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace apr22_hotel
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            adatbetoltes();
        }

        struct vendegadatok
        {
            public string nev;
            public string szigszam;
        }
        vendegadatok[] vendeg = new vendegadatok[100];

        struct foglalasadatok
        {
            public string nev;
            public string szobatipus;
            public int ejszakak;
        }
        foglalasadatok[] foglalasok = new foglalasadatok[100];
        string[] szobak = new string[20];
        int dbv,dbszoba,dbf = 0;

        private void adatbetoltes()
        {
            string[] fajlbol = File.ReadAllLines("szobak.txt");

            for (int i = 0; i < fajlbol.Length; i++)
            {
               szobak[dbszoba] = fajlbol[i];
                listBoxszobak.Items.Add(szobak[dbszoba]);
                dbszoba++;
            }

            string[] fajlbol2 = File.ReadAllLines("vendeglista1.txt");

            for (int j = 0; j < fajlbol2.Length; j++)
            {
                string[] seged = fajlbol2[j].Split('\t');
                vendeg[dbv].nev = seged[0];
                vendeg[dbv].szigszam = seged[1];
                comboBoxvendegek.Items.Add(vendeg[dbv].nev);
                comboBoxvendegek.Sorted = comboBoxvendegek.Sorted = true;
                dbv++;
            }
        }

        private void buttonkilepes_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            /*if (MessageBox.Show("Valóban kilép?","Figyelmeztetés",
                MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }*/
        }

        private void buttonfoglalasmentes_Click(object sender, EventArgs e)
        {
            FileStream f = new FileStream("foglalasok.txt",FileMode.Create);
            StreamWriter f_iro = new StreamWriter(f, Encoding.UTF8);

            for (int i = 0; i < dbf; i++)
            {
                f_iro.WriteLine("{0}\t{1}\t{2}",foglalasok[i].nev,foglalasok[i].szobatipus,foglalasok[i].ejszakak);
            }
            f_iro.Close();
            f.Close();
            MessageBox.Show("Kimentettem a jelenlegi foglalásokat a foglalasok.txt-be.", "Figyelem",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileStream f2 = new FileStream("vendeglista_uj.txt",FileMode.Create);
            StreamWriter fajlbair = new StreamWriter(f2, Encoding.UTF8);

            for (int i = 0; i < dbv; i++)
            {
                fajlbair.WriteLine("{0}\t{1}",vendeg[i].nev,vendeg[i].szigszam);
            }            
            fajlbair.Close();
            f2.Close();
            MessageBox.Show("Kimentettem az aktuális vendégek adatait a vendeglista_uj.txt-be.", "Figyelem",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonaktfoglalasok_Click(object sender, EventArgs e)
        {
            MegtekintoForm ujform = new MegtekintoForm();
            ujform.ShowDialog();
        }

        private void kilépésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void újVendégHozzáadásaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonujvendeg_Click(sender, e);
        }

        private void újFoglalásRögzítéseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonfoglalas_Click(sender, e);
        }

        private void elmentemAVendéglistátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1_Click(sender, e);
        }

        private void foglalásokElmentéseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonfoglalasmentes_Click(sender, e);
        }

        private void foglalásokMegtekintéseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonaktfoglalasok_Click(sender, e);
        }

        private void buttonfoglalas_Click(object sender, EventArgs e)
        {
            foglalasok[dbf].nev = comboBoxvendegek.Text;
            foglalasok[dbf].szobatipus = listBoxszobak.SelectedItem.ToString();
            foglalasok[dbf].ejszakak = Convert.ToInt32(textBoxejszakak.Text);
            dbf++;

            MessageBox.Show("A kiválasztott foglalási adatokat eltároltam.","Figyelem",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonujvendeg_Click(object sender, EventArgs e)
        {
            Form2ujvendeg adatbevitel = new Form2ujvendeg();            
            DialogResult form = adatbevitel.ShowDialog();

            adatbevitel.StartPosition = FormStartPosition.CenterScreen;
            string n, sz = "";
            adatbevitel.Beolvas(out n, out sz);
            if (form == DialogResult.OK)
            {
                vendeg[dbv].nev = n;
                vendeg[dbv].szigszam = sz;
                comboBoxvendegek.Items.Add(vendeg[dbv].nev);
                comboBoxvendegek.Sorted = comboBoxvendegek.Sorted = true;
                dbv++;
            }
        }
    }

    class MegtekintoForm : Form
    {
        ListBox foglalasok = new ListBox();
        Button bezargomb = new Button();
        Button megnyitgomb = new Button();

        public MegtekintoForm()
        {
            this.Size = new Size(400,350);
            this.Text = "Foglalások részletezve";
            this.MaximumSize = new Size(400, 350);
            this.MinimumSize = new Size(400, 350);

            foglalasok.Location = new Point(10,10);
            foglalasok.Size = new Size(240,200);

            bezargomb.Text = "Vissza";
            bezargomb.Location = new Point(270,150);
            bezargomb.Click += new EventHandler(Bezar);
            bezargomb.Size = new Size(100,50);

            megnyitgomb.Text = "Megnyitok más adatokat";
            megnyitgomb.Location = new Point(270, 40);
            megnyitgomb.Click += new EventHandler(Megnyit);
            megnyitgomb.Size = new Size(100, 50);

            foglalasok.Items.Clear();

            string[] f = File.ReadAllLines("foglalasok.txt");
            for (int i = 0; i < f.Length; i++)
            {
                foglalasok.Items.Add(f[i]);
            }

            Controls.Add(foglalasok);
            Controls.Add(bezargomb);
            Controls.Add(megnyitgomb);
        }

        private void Bezar(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Megnyit(object sender, EventArgs e)
        {
            foglalasok.Items.Clear();
            OpenFileDialog fajl = new OpenFileDialog();
            DialogResult eredm = fajl.ShowDialog();
            if (eredm == DialogResult.OK)
                try
                {
                    string[] beolvas = File.ReadAllLines(fajl.FileName);
                    for (int i = 0; i < beolvas.Length; i++)
                    {
                        foglalasok.Items.Add(beolvas[i]);
                    }
                }
                catch
                {
                    MessageBox.Show("Nem találtam megjeleníthető adatokat!", "HIBA",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }
    }
}
