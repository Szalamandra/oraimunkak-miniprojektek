﻿
namespace apr22_hotel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxvendegek = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonujvendeg = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.listBoxszobak = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxejszakak = new System.Windows.Forms.TextBox();
            this.buttonfoglalas = new System.Windows.Forms.Button();
            this.buttonkilepes = new System.Windows.Forms.Button();
            this.buttonfoglalasmentes = new System.Windows.Forms.Button();
            this.buttonaktfoglalasok = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.vendégekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.újVendégHozzáadásaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.elmentemAVendéglistátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.foglalásokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.újFoglalásRögzítéseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.foglalásokElmentéseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.foglalásokMegtekintéseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kilépésToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBoxvendegek
            // 
            this.comboBoxvendegek.FormattingEnabled = true;
            this.comboBoxvendegek.Location = new System.Drawing.Point(36, 68);
            this.comboBoxvendegek.Name = "comboBoxvendegek";
            this.comboBoxvendegek.Size = new System.Drawing.Size(215, 21);
            this.comboBoxvendegek.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(33, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Vendég:";
            // 
            // buttonujvendeg
            // 
            this.buttonujvendeg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonujvendeg.Location = new System.Drawing.Point(36, 116);
            this.buttonujvendeg.Name = "buttonujvendeg";
            this.buttonujvendeg.Size = new System.Drawing.Size(172, 41);
            this.buttonujvendeg.TabIndex = 2;
            this.buttonujvendeg.Text = "Új vendég hozzáadása";
            this.buttonujvendeg.UseVisualStyleBackColor = true;
            this.buttonujvendeg.Click += new System.EventHandler(this.buttonujvendeg_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(287, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Szobák:";
            // 
            // listBoxszobak
            // 
            this.listBoxszobak.FormattingEnabled = true;
            this.listBoxszobak.Location = new System.Drawing.Point(288, 66);
            this.listBoxszobak.Name = "listBoxszobak";
            this.listBoxszobak.Size = new System.Drawing.Size(222, 212);
            this.listBoxszobak.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(543, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Éjszakák száma:";
            // 
            // textBoxejszakak
            // 
            this.textBoxejszakak.Location = new System.Drawing.Point(547, 69);
            this.textBoxejszakak.Name = "textBoxejszakak";
            this.textBoxejszakak.Size = new System.Drawing.Size(112, 20);
            this.textBoxejszakak.TabIndex = 6;
            // 
            // buttonfoglalas
            // 
            this.buttonfoglalas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonfoglalas.Location = new System.Drawing.Point(37, 184);
            this.buttonfoglalas.Name = "buttonfoglalas";
            this.buttonfoglalas.Size = new System.Drawing.Size(171, 36);
            this.buttonfoglalas.TabIndex = 7;
            this.buttonfoglalas.Text = "Foglalás rögzítése";
            this.buttonfoglalas.UseVisualStyleBackColor = true;
            this.buttonfoglalas.Click += new System.EventHandler(this.buttonfoglalas_Click);
            // 
            // buttonkilepes
            // 
            this.buttonkilepes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonkilepes.Location = new System.Drawing.Point(541, 255);
            this.buttonkilepes.Name = "buttonkilepes";
            this.buttonkilepes.Size = new System.Drawing.Size(133, 36);
            this.buttonkilepes.TabIndex = 8;
            this.buttonkilepes.Text = "Kilépés";
            this.buttonkilepes.UseVisualStyleBackColor = true;
            this.buttonkilepes.Click += new System.EventHandler(this.buttonkilepes_Click);
            // 
            // buttonfoglalasmentes
            // 
            this.buttonfoglalasmentes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonfoglalasmentes.Location = new System.Drawing.Point(37, 255);
            this.buttonfoglalasmentes.Name = "buttonfoglalasmentes";
            this.buttonfoglalasmentes.Size = new System.Drawing.Size(171, 36);
            this.buttonfoglalasmentes.TabIndex = 9;
            this.buttonfoglalasmentes.Text = "Elmentem a foglalásokat";
            this.buttonfoglalasmentes.UseVisualStyleBackColor = true;
            this.buttonfoglalasmentes.Click += new System.EventHandler(this.buttonfoglalasmentes_Click);
            // 
            // buttonaktfoglalasok
            // 
            this.buttonaktfoglalasok.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonaktfoglalasok.Location = new System.Drawing.Point(541, 163);
            this.buttonaktfoglalasok.Name = "buttonaktfoglalasok";
            this.buttonaktfoglalasok.Size = new System.Drawing.Size(133, 57);
            this.buttonaktfoglalasok.TabIndex = 10;
            this.buttonaktfoglalasok.Text = "Megnézem az aktuális foglalásokat";
            this.buttonaktfoglalasok.UseVisualStyleBackColor = true;
            this.buttonaktfoglalasok.Click += new System.EventHandler(this.buttonaktfoglalasok_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(541, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 36);
            this.button1.TabIndex = 11;
            this.button1.Text = "Elmentem a vendéglistát";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vendégekToolStripMenuItem,
            this.foglalásokToolStripMenuItem,
            this.kilépésToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(724, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // vendégekToolStripMenuItem
            // 
            this.vendégekToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.újVendégHozzáadásaToolStripMenuItem,
            this.elmentemAVendéglistátToolStripMenuItem});
            this.vendégekToolStripMenuItem.Name = "vendégekToolStripMenuItem";
            this.vendégekToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.vendégekToolStripMenuItem.Text = "Vendégek";
            // 
            // újVendégHozzáadásaToolStripMenuItem
            // 
            this.újVendégHozzáadásaToolStripMenuItem.Name = "újVendégHozzáadásaToolStripMenuItem";
            this.újVendégHozzáadásaToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.újVendégHozzáadásaToolStripMenuItem.Text = "Új vendég hozzáadása";
            this.újVendégHozzáadásaToolStripMenuItem.Click += new System.EventHandler(this.újVendégHozzáadásaToolStripMenuItem_Click);
            // 
            // elmentemAVendéglistátToolStripMenuItem
            // 
            this.elmentemAVendéglistátToolStripMenuItem.Name = "elmentemAVendéglistátToolStripMenuItem";
            this.elmentemAVendéglistátToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.elmentemAVendéglistátToolStripMenuItem.Text = "Elmentem a vendéglistát";
            this.elmentemAVendéglistátToolStripMenuItem.Click += new System.EventHandler(this.elmentemAVendéglistátToolStripMenuItem_Click);
            // 
            // foglalásokToolStripMenuItem
            // 
            this.foglalásokToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.újFoglalásRögzítéseToolStripMenuItem,
            this.foglalásokElmentéseToolStripMenuItem,
            this.foglalásokMegtekintéseToolStripMenuItem});
            this.foglalásokToolStripMenuItem.Name = "foglalásokToolStripMenuItem";
            this.foglalásokToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.foglalásokToolStripMenuItem.Text = "Foglalások";
            // 
            // újFoglalásRögzítéseToolStripMenuItem
            // 
            this.újFoglalásRögzítéseToolStripMenuItem.Name = "újFoglalásRögzítéseToolStripMenuItem";
            this.újFoglalásRögzítéseToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.újFoglalásRögzítéseToolStripMenuItem.Text = "Új foglalás rögzítése";
            this.újFoglalásRögzítéseToolStripMenuItem.Click += new System.EventHandler(this.újFoglalásRögzítéseToolStripMenuItem_Click);
            // 
            // foglalásokElmentéseToolStripMenuItem
            // 
            this.foglalásokElmentéseToolStripMenuItem.Name = "foglalásokElmentéseToolStripMenuItem";
            this.foglalásokElmentéseToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.foglalásokElmentéseToolStripMenuItem.Text = "Foglalások elmentése";
            this.foglalásokElmentéseToolStripMenuItem.Click += new System.EventHandler(this.foglalásokElmentéseToolStripMenuItem_Click);
            // 
            // foglalásokMegtekintéseToolStripMenuItem
            // 
            this.foglalásokMegtekintéseToolStripMenuItem.Name = "foglalásokMegtekintéseToolStripMenuItem";
            this.foglalásokMegtekintéseToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.foglalásokMegtekintéseToolStripMenuItem.Text = "Foglalások megtekintése";
            this.foglalásokMegtekintéseToolStripMenuItem.Click += new System.EventHandler(this.foglalásokMegtekintéseToolStripMenuItem_Click);
            // 
            // kilépésToolStripMenuItem
            // 
            this.kilépésToolStripMenuItem.Name = "kilépésToolStripMenuItem";
            this.kilépésToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.kilépésToolStripMenuItem.Text = "Kilépés";
            this.kilépésToolStripMenuItem.Click += new System.EventHandler(this.kilépésToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 321);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonaktfoglalasok);
            this.Controls.Add(this.buttonfoglalasmentes);
            this.Controls.Add(this.buttonkilepes);
            this.Controls.Add(this.buttonfoglalas);
            this.Controls.Add(this.textBoxejszakak);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listBoxszobak);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonujvendeg);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxvendegek);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(740, 360);
            this.MinimumSize = new System.Drawing.Size(740, 360);
            this.Name = "Form1";
            this.Text = "Szobanyilvántartás";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxvendegek;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonujvendeg;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBoxszobak;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxejszakak;
        private System.Windows.Forms.Button buttonfoglalas;
        private System.Windows.Forms.Button buttonkilepes;
        private System.Windows.Forms.Button buttonfoglalasmentes;
        private System.Windows.Forms.Button buttonaktfoglalasok;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem vendégekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem újVendégHozzáadásaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem elmentemAVendéglistátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem foglalásokToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem újFoglalásRögzítéseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem foglalásokElmentéseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem foglalásokMegtekintéseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kilépésToolStripMenuItem;
    }
}

