﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace apr22_hotel
{
    public partial class Form2ujvendeg : Form
    {
        public Form2ujvendeg()
        {
            InitializeComponent();
        }

        public void Beolvas(out string vendegnev, out string szigszam)
        {
            vendegnev = textBox1.Text;
            szigszam = textBox2.Text;
        }

        private void Form2ujvendeg_Load(object sender, EventArgs e)
        {
            buttonmentes.DialogResult = DialogResult.OK;
            buttonmegsem.DialogResult = DialogResult.Cancel;
            this.AcceptButton = buttonmentes;
            this.CancelButton = buttonmegsem;
        }
    }
}
