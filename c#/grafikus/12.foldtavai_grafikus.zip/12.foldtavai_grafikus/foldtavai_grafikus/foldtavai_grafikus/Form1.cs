﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace foldtavai_grafikus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            adatbetoltes();
        }
        struct toadatok
        {
            public string nev;
            public int terulet;
            public string teruletbeolvas;
            public string orszag;
            public int termin;
            public int termax;
        }
        static toadatok[] adat = new toadatok[200];

        void adatbetoltes()
        {
            string[] fajlbeolvas = File.ReadAllLines("tavak.csv");
            int sorok = 0;

            for (int i = 1; i < fajlbeolvas.Count(); i++)
            {
                string[] egysor = fajlbeolvas[i].Split(';');

                adat[sorok].nev = egysor[0];
                adat[sorok].orszag = egysor[2];
                adat[sorok].teruletbeolvas = egysor[1];

                if (adat[sorok].teruletbeolvas.Contains('-'))
                {
                    string[] teruletseged = egysor[1].Split('-');
                    adat[sorok].termin = Convert.ToInt32(teruletseged[0]);
                    adat[sorok].termax = Convert.ToInt32(teruletseged[1]);

                    adat[sorok].terulet = (adat[sorok].termin + adat[sorok].termax) / 2;
                }
                else adat[sorok].terulet = Convert.ToInt32(egysor[1]);

                sorok++;
            }
            int todb = sorok;

            listBox1.Items.Add("Név:\t Terület:\t Ország(ok):");
            for (int j = 0;  j < todb;  j++)
            {
                listBox1.Items.Add(adat[j].nev +"\t"+ adat[j].teruletbeolvas + "\t" + adat[j].orszag);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox4.Text != "")
            {
                try
                {
                    //gombnyomásra kerüljenek az adatok egy új fájlba, vagy a forrás adataink végére
                    /*  FileStream f2 = new FileStream("tavak.csv", FileMode.Append);
                     *  StreamWriter beiro = new StreamWriter(f2, System.Text.Encoding.Utf8);
                     *  */
                    FileStream f1 = new FileStream("ujtavak.txt", FileMode.Create);
                    StreamWriter beiro = new StreamWriter(f1);

                    string toneve = textBox1.Text;
                    string toorszag = textBox4.Text;
                    int toterulet = int.Parse(textBox2.Text);

                    beiro.WriteLine("{0};{1};{2}", toneve, toterulet, toorszag);

                    beiro.Close();
                    f1.Close();

                    MessageBox.Show("Az állomány bővítése sikeres volt.", "Visszajelzés");
                }
                catch
                {
                    MessageBox.Show("Sikertelen volt a fájlbaírás", "Visszajelzés");
                }
            }
            else MessageBox.Show("Nem töltöttél ki minden mezőt.", "HIBA");
        }
    }
}
