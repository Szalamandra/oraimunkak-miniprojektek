<!--Hexadecagonter dolgozat, készítette: Zsigmond Réka, 2021.03.13. -->

<?php
require_once 'connection.php';
require_once 'functions.php';

$connection=connectDb();

$data = json_decode($_POST['data'],TRUE);

//kiíratás
$siker = TRUE;
if($siker) {
    echo 'siker\n';
    print_r($data);
    insertHexadecagon($connection, $data); 
    
}else{
    echo 'Hiba! Az adatbázisba írás sikertelen!';
}
?>



<?php closeDb($connection);  ?>
