<!--Hexadecagonter dolgozat, készítette: Zsigmond Réka, 2021.03.13. -->


<?php


$db['host'] = 'localhost';
$db['user'] = 'hexadecagon';
$db['pass'] = '';
$db['name'] = 'hexadecagon';
