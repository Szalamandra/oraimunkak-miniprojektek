<!--Hexadecagonter dolgozat, készítette: Zsigmond Réka, 2021.03.13. -->


<?php
include_once 'config.php';
 
function connectDb() {
	global $db;
	$conn = mysqli_connect(
		$db['host'], 
        $db['user'],
		$db['pass'],
        $db['name'], 
		
	);

	if (!$conn) {
		error_log('Hiba! A kapcsolódás sikertelen!');
	}
    if(!$db['pass']==''){
        error.log("Helytelen jelszó!");
    }
	
    echo ("sikerült connection haver");
	$conn->set_charset("utf8");
	return $conn;
}
 
function closeDb($conn) {
	mysqli_close($conn);
	echo("bezartam a connectiont");
}

$connection=connectDb();
closeDb($connection);