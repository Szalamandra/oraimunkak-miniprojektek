<!--Hexadecagonter dolgozat, készítette: Zsigmond Réka, 2021.03.13. -->


<?php
$DBNAME='hexadecagon';
$TABLE='hexadecagonMasolat';

function createDatabase($conn){
    $sql="CREATE DATABASE IF NOT EXISTS ${DBNAME} DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
    USE ${DBNAME}";
   
    $conn->query($sql);


}

function createTable($conn){
    $sql="CREATE TABLE IF NOT EXISTS {$TABLE} ( 'az' INT(12) NOT NULL PRIMARY_KEY AUTO_INCREMENT, 'oldal' INT(6), 'szin' VARCHAR(100), 'tulaj' VARCHAR(100)";
   
    $conn->query($sql);
    

}

function insertHexadecagon($conn, $data) {
	$sql = "INSERT INTO hexadecagon (oldal, szin, tulaj) 
        VALUES (\"{$data['oldal']}\", \"{$data['szin']}\",\"{$data['nev']}\")";
	$conn->query($sql);
}

function deleteHexadecagon($conn,$valasztott) {
    $sql="DELETE FROM hexadecagon WHERE az={$valasztott}";
	$result=$conn->query($sql);




    if($result){
        echo($result."sikerült a törlés");
    }
    elseif(!$valasztott){
        echo("nincs ilyen az adatbazisban");
    }
    else{
        echo("\nstg went wrong");
    }

}



