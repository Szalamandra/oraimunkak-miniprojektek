<!--Hexadecagonter dolgozat, készítette: Zsigmond Réka, 2021.03.13. -->


<?php

require_once '../connection.php';
require_once '../functions.php';

$connection=connectDb();
$testData=array(  
    "oldal"=>3,
    "szin"=>"tesztFeher",
    "nev"=>"testBalu"
);
$testDelete=29;

$DBNAME='hexadecagon';
$TABLE='hexadecagon';


if(!isset($DBNAME)){
    if($conn){
    createDatabase($conn);
    echo("csináltam egy új DB-t, mert nem volt");
        if(!isset($TABLE)){
            createTable($conn);
            echo("csináltam neked táblát");
        }
        else{
            error_log("stg went wrong creating table");
        }

}
    else{
        die(connection_error);
        echo("connection failed");
    }
    
}

echo("minden okés volt, ypur database is ready to work!");


$elsoKor=true;
echo "<br>".$elsoKor;
if($elsoKor){
    echo(
<<<EOT
<form method="post" action="testInsertion.php">
<label for="">Melyik azonosítójú elemet szeretné törölni?</label>
<input type="text" id="valasztottElem" name="valasztott" placeholder="szam">
<br>
<button type="submit" name="testInsertion">Küld</button></form>
EOT
);

$elsoKor=FALSE;



if(!$elsoKor){
   
if(isset($valasztott)){
    $valasztott=intval($_POST[$valasztott]);
    echo "valasztott: ".$valasztott;
    if($valasztott>0){
        echo "<form method=\"post\" action=\"testInsertion.php\">
        <label>Vakóban törölni akarja?</label>
        <input type=\"radio\" name=\"torolheto\" value=\"igen\">
        <label for=\"male\">igen</label><br>
        <input type=\"radio\" name=\"torolheto\" value=\"nem\">
        <label for=\"female\">nem</label><br>
        <button type=\"submit\" name=\"testInsertion\">Jóváhagy</button>
        </form>";

    
    if(isset($torolheto)){  
        $torolheto=$_POST["torolheto"];
        if($torolheto==="igen"){
            $testDelete=$valasztott;
            deleteHexadecagon($connection,$testDelete);
    }
    else
        printf("akkor nem törlök semmit");}

    }


    $elsoKor=TRUE;
    }      

//insertHexadecagon($connection, $testData);
}//masodikor
}//elsokor=true

/*<button type=\"radio\" id=\"nem\" name=\"torolheto\" value=\"nem\" checked>igen</button>
        <button type=\"radio\" id=\"igen\" name=\"torolheto\" value=\"igen\"> nem</button><br>
        </form>";*/