/*Hexadecagonter dolgozat, készítette: Zsigmond Réka, 2021.03.13.*/

const FOGADOURL = 'php/fogad.php';
const IMGHEXADECAGON='<svg width="200px" height="200px" viewBox="0 0 200 200" version="1.1"><polygon style="stroke-width:2.5px" points="118.728670913548,194.15538691871 81.2713290864517,194.15538691871 46.6652576301182,179.821082781044 20.1789172189557,153.334742369882 5.84461308128988,118.728670913548 5.84461308128986,81.2713290864517 20.1789172189556,46.6652576301182 46.6652576301182,20.1789172189557 81.2713290864517,5.84461308128986 118.728670913548,5.84461308128989 153.334742369882,20.1789172189557 179.821082781044,46.6652576301183 194.15538691871,81.2713290864519 194.15538691871,118.728670913549 179.821082781044,153.334742369882 153.334742369882,179.821082781045"/></svg>';

function Hexadecagon(nev="", oldal = 1, szin="") {
    let hd = new Object();
    
    hd.nev = nev,
    hd.oldal = parseInt(oldal),
    hd.oldalBeallit = function () { return oldal },
    hd.terulet = function () { return (4 * Math.pow(oldal, 2) * (1 / (Math.tan  (Math.PI / 16)))).toFixed(2);},
    
    hd.szin = function () {
        
        if (szin === "") {
            let szinRGB = [];
            for (let i = 0; i < 3; i++) {
                
                let c1 = (Math.random() * 250).toPrecision(3).toString();
                szinRGB.push(c1);
            }
            szin = "rgb(" + szinRGB.join(",") + ")";
            console.log(szin);
        }
        else { szin = szin; }
        return szin;
        }
    
    return hd;
};


function visszaad(tombData,hexa) { 
    tombData.forEach(element => {
        console.log(element.css("fill",hexa.szin));
    });

};

let teruletGomb=function canvasCsinalDiv(divSelector) {
    //if (!$('.rajz').length) {
    { $(divSelector).append('<div class="rajz"><button class="torolGomb">Töröl</button></div>').off("click"); }
    
}


let szamolGombActive = true;   //validation-hez

$('document').ready(function () {
     $('#oldal').keyup(function () {
     //little validation
                let message = "<div class='eltavDiv'><p>Pozitív egész számot adjon meg!</p></div>";
        if( $(this).next("div"))
            $(".eltavDiv").remove();
        
         if (parseInt($(this).val()) <= 0 || parseInt($(this).val()).isNaN) {
             $(this).after(message);
             szamolGombActive = false
         }
         else
             szamolGombActive = true;
           
    });
  
 
    
        $('#szamolGomb').click(function () {
            

            if(szamolGombActive){
            let oldal = $('#oldal').val();
            let szin = $('#szin').val().trim().toLowerCase();
            let nev = $('#nev').val().trim().toLowerCase();
                        

        
            let hexa = new Hexadecagon(nev, oldal, szin);
            hexa.szin = hexa.szin();
        
            let jsonhexa = JSON.stringify(hexa);
            //let jsonOldalSzin = JSON.stringify(hexa.szin);
            console.log(jsonhexa);
            //elküldeni database-be
            $.post(FOGADOURL, {
                data: jsonhexa

            })
                .done(function (result) {
                    if (result == 'siker') {
                        console.log('A mentés sikeres');
                    } else {
                        console.log(result);
                    }
                    console.log(result);
                });
                
            
                $('#rajzTerDiv')
                    .append($('<div class="hexaDiv"><p>Terület:</p></div>')
                        .append(IMGHEXADECAGON)
                        .append(hexa.terulet)
                        .append('<div class="rajz"><button class="torolGomb">Töröl</button></div>'));
        
           

           
                //hexadecagon formazasa
                $("svg:last").css("fill", hexa.szin);
        
                $('.torolGomb').click(function () {
                    $(this)
                        .parent(".rajz")
                        .parent(".hexaDiv")
                        .remove();
             

                });
            }
            
        });         /* #szamolGomb */

   
   
});  //document ready