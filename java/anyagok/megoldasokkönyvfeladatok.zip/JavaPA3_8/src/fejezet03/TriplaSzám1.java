public class TriplaSzám1 {
  public static void main(String[] args) {
    System.out.println("Szám háromszorosa");
    int x;
    x = extra.Console.readInt("Szám: ");
    int xTripla;
    xTripla = 3*x;
    System.out.println("A szám háromszorosa: "+xTripla);
  }
}