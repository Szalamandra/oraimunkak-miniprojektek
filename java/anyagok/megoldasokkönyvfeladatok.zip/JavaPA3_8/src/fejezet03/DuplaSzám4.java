public class DuplaSzám4 {
  public static void main(String[] args) {
    System.out.println("Szám kétszerese");
    int x = extra.Console.readInt("Szám: ");
    System.out.println("A szám kétszerese: "+2*x);      //1
  }
}