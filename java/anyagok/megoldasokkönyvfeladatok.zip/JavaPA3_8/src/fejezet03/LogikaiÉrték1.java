public class LogikaiÉrték1 {
  public static void main(String[] args) {
    boolean szépAzIdő = true;                           //1
    System.out.println("Szép az idő? "+szépAzIdő);      //2
    szépAzIdő = false;                                  //3
    System.out.println("Szép az idő? "+szépAzIdő);      //4
  }
}