public class EgyKarakter1 {
  public static void main(String[] args) {
    char k = extra.Console.readChar("Karakter: ");      //1
    System.out.println("A beolvasott karakter "+
      "háromszor:\n"+k+"\n"+k+"\n"+k);                  //2
  }
}