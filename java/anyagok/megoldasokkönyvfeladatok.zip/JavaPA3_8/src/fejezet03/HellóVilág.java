public class HellóVilág {                               //1
  public static void main(String[] args) {              //2
    System.out.println("Helló világ!");                 //3
  }                                                     //4
}                                                       //5
