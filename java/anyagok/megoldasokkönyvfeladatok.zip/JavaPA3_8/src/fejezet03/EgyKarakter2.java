public class EgyKarakter2 {
  public static void main(String[] args) {
    char k = extra.Console.readChar("Karakter: ");
    System.out.println("A beolvasott karakter "+
      "háromszor: "+k+k+k);
  }
}