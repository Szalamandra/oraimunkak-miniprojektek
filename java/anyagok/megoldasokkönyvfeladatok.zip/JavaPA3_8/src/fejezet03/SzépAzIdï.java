public class SzépAzIdő {
  public static void main(String[] args) {
    System.out.println("Nyár van, szép az idő!");
  }
}