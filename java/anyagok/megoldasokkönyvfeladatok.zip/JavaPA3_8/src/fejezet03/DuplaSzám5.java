public class DuplaSzám5 {
  public static void main(String[] args) {
    System.out.println("Szám kétszerese");
    long x = extra.Console.readLong("Szám: ");          //1
    System.out.println("A szám kétszerese: "+2*x);
  }
}