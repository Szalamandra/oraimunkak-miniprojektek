public class DuplaSzám1 {
  public static void main(String[] args) {
    System.out.println("Szám kétszerese");              //1
    int x;                                              //2
    x = extra.Console.readInt("Szám: ");                //3
    int xDupla;                                         //4
    xDupla = 2*x;                                       //5
    System.out.println("A szám kétszerese: "+xDupla);   //6
  }
}