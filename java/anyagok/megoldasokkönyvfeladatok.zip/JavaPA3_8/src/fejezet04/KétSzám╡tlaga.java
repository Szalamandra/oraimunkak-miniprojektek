public class KétSzámÁtlaga {
  public static void main(String[] args) {
    System.out.println("Két szám átlaga");
    double a=extra.Console.readDouble("1. szám: ");
    double b=extra.Console.readDouble("2. szám: ");
    System.out.println("A két szám átlaga: "+(a+b)/2);
  }
}