public class AngolABCKisbetűi {
  public static void main(String[] args) {
    System.out.print("Az angol ABC kisbetűi: ");
    for(char k='a'; k<='z'; k++)
      System.out.print(k+", ");
  }
}