public class AngolABCNagybetűi {
  public static void main(String[] args) {
    System.out.print("Az angol ABC nagybetűi: ");
    for(char k='A'; k<='Z'; k++)
      System.out.print(k+", ");
  }
}