public class Első10PozitívPárosSzám2 {
  public static void main(String[] args) {
    System.out.println("Az első 10 pozitív páros szám: ");
    for(int db=1; db<=10; ++db)
      System.out.print(db*2+", ");
  }
}