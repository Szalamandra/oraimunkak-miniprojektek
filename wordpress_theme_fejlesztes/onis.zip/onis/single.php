<?php
/**
 * Single post template file.
 *
 * @package onis
 */

get_header();

?>

	<div id="primaryPage">
		<main id="main" class="site-main" role="main">
			<div class="container">
						<?php
						if ( have_posts() ) 
							?>
							<div class="">
							<?php
							if ( is_home() && ! is_front_page() ) {
								?>
								<header class="">
									<h1 class="page-title screen-reader-text">
										<?php single_post_title(); ?>
									</h1>
								</header>
								<?php
							}
							while ( have_posts() ) : the_post();

								get_template_part( 'template-parts/content' );

							endwhile;
							?>

						<?php

							get_template_part( 'template-parts/content','none' );

							?>

							</div>
						
					</div>
					<?php
					// Next and previous link for page navigation.
					?>
					<div class=""><?php previous_post_link(); ?></div>
					<div class=""><?php next_post_link(); ?></div>
				
					<?php get_sidebar(); ?>
			
		</main>
	</div>

<?php
get_footer();

