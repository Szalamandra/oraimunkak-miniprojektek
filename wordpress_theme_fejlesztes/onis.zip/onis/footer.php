<?php
/**
 
 * @package onis
 */?>

<footer id="all_page_footer">
	<?php 
	wp_nav_menu(
				array(
					'theme_location' => 'footer_menu',
					'menu_id'        => 'all_menu-3',
					'menu_class' 	=>'menu itemFooter',
				)
			);?>
            <div class="itemFooter">
				<p>Copyright 2021</p>
				<p>*Tevékenységeim nem gyógyító tevékenységek, nem minősülnek pszichoterápiának.
            </div>
            <div id="all_socialIkonok" class="itemFooter">
                <a href="https://www.facebook.com/lelkizz/"><i class="fab fa-facebook"></i></a>
                <i class="fab fa-instagram-square"></i>
                <i class="fab fa-whatsapp-square"></i>
            </div>
	
	<?php if ( is_active_sidebar( 'sidebar-3' ) ) { ?>
		<aside>
			<?php dynamic_sidebar( 'sidebar-3' ); ?>
		</aside>
	<?php } ?>

</footer>
	<?php // all js scripts are attached here ?>
		<?php wp_footer(); ?>

</div> <!--#page.site or #frontPage.no-sidebar -->
</body>
</html>
