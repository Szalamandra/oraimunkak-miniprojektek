<?php
function onis_styles() {
   wp_register_style( 'onis-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style('onis-style',get_template_directory_uri() . '/style.css',array(), wp_get_theme()->get( 'ONIS_VERSION' ));
	wp_register_style( 'onis-fontawesome', 'https://use.fontawesome.com/releases/v5.0.13/css/all.css');
	wp_enqueue_style( 'onis-fontawesome');
    /*wp_register_style( 'onis-rtl-style', get_template_directory_uri() . '/style-rtl.css' );
	wp_enqueue_style( 'onis-rtl-style');
	*/
//at first registering style sheets as you can manage them easier later on.
  
/*for supporting both editor and my own style
function wp_common_block_scripts_and_styles() {
    if ( is_admin() && ! wp_should_load_block_editor_scripts_and_styles() ) {
        return;
    }
 
    wp_enqueue_style( 'wp-block-library' );
 
    if ( current_theme_supports( 'wp-block-styles' ) ) {
        wp_enqueue_style( 'wp-block-library' );
    }

}*/

	
}
add_action( 'wp_enqueue_scripts', 'onis_styles', 100 );

/* for adding custom styleshhet for gutenberg 
https://developer.wordpress.org/block-editor/handbook/faq/#editor-shortcuts
function gutenbergtheme_editor_styles() {
    wp_enqueue_style( 'gutenbergtheme-blocks-style', get_template_directory_uri() . '/blocks.css');
}
add_action( 'enqueue_block_editor_assets', 'gutenbergtheme_editor_styles' );*/