
 <?php 
 /**
 * Register nav menus and locations. This function automatically registers custom menu support for the theme therefore you do not need to call add_theme_support( 'menus' );
* This function actually works by simply calling register_nav_menus() in the following way:
*1
*register_nav_menus( array( $location => $description ) );
*You may use wp_nav_menu() to display your custom menu.
 * @action wp_nav_menu
 * $args
*(array) (Optional) Array of nav menu arguments.

*'menu'
*(int|string|WP_Term) Desired menu. Accepts a menu ID, slug, name, or object.
*'menu_class'
*(string) CSS class to use for the ul element which forms the menu. Default 'menu'.
*'menu_id'
*(string) The ID that is applied to the ul element which forms the menu. Default is the menu slug, incremented.
*'container'
*(string) Whether to wrap the ul, and what to wrap it with. Default 'div'.
*'container_class'
*(string) Class that is applied to the container. Default 'menu-{menu slug}-container'.
*'container_id'
*(string) The ID that is applied to the container.
*'container_aria_label'
*(string) The aria-label attribute that is applied to the container when it's a nav element.
	 */
	if ( ! function_exists( 'onis_register_nav_menu' ) ) {
 
    function onis_register_nav_menu(){
        register_nav_menus( array(
			'primary_menu_left' =>  'Primary Menu Left',
			'primary_menu_right' =>'Primary Menu Right',
			'primary_menu_all' => 'Primary Menu All',
			'menu_mobil_all' => 'Mobile Menu',
			'menu_mobil_home' => 'Mobile Menu homepage',
            'footer_menu'  =>  'Footer Menu',
        ) );
	}
	add_action( 'after_setup_theme', 'onis_register_nav_menu', 0 );
}

		/*function get_registered_nav_menus() {
	        global $_wp_registered_nav_menus;
	        if ( isset( $_wp_registered_nav_menus ) ) {
	                return $_wp_registered_nav_menus;
       }
	        return array();
	}/*
 /**
  * 
 * Register sidebars for widget areas that allow for the user customizing the sites by its own.
	 * @action widgets_init
	 */