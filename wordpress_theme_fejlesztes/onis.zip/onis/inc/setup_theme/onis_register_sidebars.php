<?php

function onis_register_sidebars() {

		register_sidebar(
			[
				'name'          => esc_html__( 'Primary Sidebar', 'onis' ),
				'id'            => 'sidebar-1',
				'class'			=> 'custom',  /*ezzel lesz sidebar-custom nad I can use to customize it in the editor*/ 
				'description'   => '',
				'before_widget' => '<div id="%1$s" class="widget widget-sidebar %2$s">',  /* %1$s exchange the sidebar-1 the %2s$s for the class*/
				'after_widget'  => '</div>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			],

			[
				'name'          => esc_html__( 'Footer', 'onis' ),
				'id'            => 'sidebar-3',
				'class'			=> 'custom', 
				'description'   => '',
				'before_widget' => '<div id="%1$s" class="widget widget-footer %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h4 class="widget-title">',
				'after_title'   => '</h4>',
			]
		);
	}
add_action( 'widgets_init', 'onis_register_sidebars' );