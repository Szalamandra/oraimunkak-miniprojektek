<?php 
function onis_scripts() {
	//adding scripts file in the footer(set the last parameter true)
	
	wp_register_script('onis-script',  get_template_directory_uri() . '/js/customizer.js', array( 'jquery' ), '1.0', true );
	wp_register_script('onis-nav-script',  get_template_directory_uri() . '/js/navigation.js', array( 'jquery' ), '1.0', true);
	wp_register_script('onis-practice-script',  get_template_directory_uri() .'/js/homePage.js', array( 'jquery' ), '1.0', true);


		/*
		it is recommended using a plugin to call jQuery
		using the google cdn. That way it stays cached
		and the site will load faster.
		*/
		wp_enqueue_script( 'jquery' );
	/*wp_enqueue_script('onis-script');*/
	wp_enqueue_script('onis-nav-script');
	/*https://developer.wordpress.org/reference/functions/is_page/  */
	if(is_page('front-page')){
		wp_enqueue_script('onis-practice-script');

	}
}
add_action( 'wp_enqueue_scripts', 'onis_scripts' );