<?php add_action('admin_head', 'my_custom_fonts');

function my_custom_fonts() {
  echo '<style>
    body, td, textarea, input, select {
      font-family: "Lucida Grande";
      font-size: 12px;
    } 
  </style>';
}

/*
enque scripts for admin pages
https://developer.wordpress.org/reference/hooks/admin_enqueue_scripts/ */

/*get_current_user_id()=='1' I read it from the database that admin is 1)*/

function onis_admin_styles() {
   
    wp_register_style( 'onis-admin-style', get_template_directory_uri() . '/admin_style.css' );
	wp_enqueue_style('onis-admin-style');
	wp_register_style( 'onis-fontawesome', 'https://use.fontawesome.com/releases/v5.0.13/css/all.css');
	wp_enqueue_style( 'onis-fontawesome');
    
}
add_action( 'admin_enqueue_scripts', 'onis_admin_styles', 100 );


//Instead of hiding admin pages from different users withh css rather use hooks removing them from the admin area. 

/*function onis_remove_admin_pages_editor(){
    if(onis_is_user_by_role('editor')){
        // user has editor role
       
        remove_menu_page( 'edit-comments.php' );
    }
    

}


    do_action( 'admin_menu', 'onis_remove_admin_pages_editor' );*/


/*remove things from admin bar(top toolbar), like the logo, etc
https://developer.wordpress.org/reference/files/wp-includes/admin-bar.php/

wp-includes/admin-bar.php
*/

add_action( 'add_admin_bar_menus', function() {
    remove_action( 'admin_bar_menu', 'wp_admin_bar_wp_menu' );
});

//Replace the login_wordpress logo to Onismerkedo
/*function my_login_logo() { ?>
    <style type="text/css">
        #login h1 a, .login h1 a {
            background-image: url(<?php wp_plugin_directory_constants().'../uploads/2020/12/Onismerkedo_logo-1-150x150.png'?>;
		height:65px;
		width:320px;
		background-size: 320px 65px;
		background-repeat: no-repeat;
        	padding-bottom: 30px;
        }
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'my_login_logo',10 );*/

function onis_login_style_enq(){
   wp_register_style( 'onis_login_style', get_template_directory_uri() . '/onis_login_style.css' );
  wp_enqueue_style( 'onis_login_style');
}


add_action( 'login_enqueue_scripts', 'onis_login_style_enq',20);


//remove dashboard things: 
//@dashboard.php dashboard_setup hook
//https://developer.wordpress.org/reference/hooks/wp_dashboard_setup/  id somehow didnt work

function onis_remove_dashboard_things(){
  $onis_admin=get_user_by( 'user_login', 'Onismerkedo');
  /*Completely remove various dashboard widgets (remember they can also be HIDDEN from admin)*/
  if(!$onis_admin){
    
      remove_meta_box( 'dashboard_quick_press',   'dashboard', 'side' );      //Quick Press widget
      remove_meta_box( 'dashboard_recent_drafts', 'dashboard', 'side' );      //Recent Drafts
      remove_meta_box( 'dashboard_primary',       'dashboard', 'side' );      //WordPress.com Blog
      remove_meta_box( 'dashboard_secondary',     'dashboard', 'side' );      //Other WordPress News
      remove_meta_box( 'dashboard_incoming_links','dashboard', 'normal' );    //Incoming Links
      remove_meta_box( 'dashboard_plugins',       'dashboard', 'normal' );    //Plugins
    remove_meta_box( 'dashboard_activity',       'dashboard', 'normal' );    //activity
    /*remove_meta_box( 'dashboard_right_now',       'dashboard', 'normal' );    //at a glance */
    remove_meta_box( 'themeisle',       'dashboard', 'normal' );    //themeisle plugin-orbit fox
    remove_meta_box( 'dashboard_activity',       'dashboard', 'normal' );    //activity
  }
}


add_action( 'wp_dashboard_setup','onis_remove_dashboard_things',20 );


//change the footer text


function onis_admin_footer_text($text){
  $text="Allways look on the bright side of life! :)";
  return $text;

}

add_filter( 'admin_footer_text', 'onis_admin_footer_text',20 );

/*apply_filters( 'admin_body_class', string $classes ) */

function onis_admin_body_class($class){
 /*if(is_page('index.php'))*/
  $class='onis_dashboard_bg';
  return $class;
}

add_filter( 'admin_body_class', 'onis_admin_body_class');