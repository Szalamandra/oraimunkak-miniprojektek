<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package onis
 */

?>

<aside id="secondary">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->
