<?php
/**
 * @package onis
 */


if ( ! defined( 'ONIS_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( 'ONIS_VERSION', '1.0.0' );
}

//select a user role(boolean) $userType can be 'editor','adminsitrator', 'subscriber' etc


function onis_is_user_by_role($userType){
     $user = wp_get_current_user();
    if (in_array($userType,$user->roles)) 
        return true;
    else
        return false;
}

//setup theme
require get_template_directory().'/inc/setup_theme/onis_setup_theme.php';

//register nav menu
require get_template_directory().'/inc/setup_theme/onis_register_menu.php';

// Add support for Block Styles.
		add_theme_support( 'wp-block-styles' );

//editor styles and features
if(onis_is_user_by_role('administrator')){
require get_template_directory().'/inc/editor/onis_editor_style.php';}

if(!onis_is_user_by_role('administrator')){
add_filter('use_block_editor_for_post', '__return_false', 10);}

/*disable guttenberg editor in every pages except admin https://kinsta.com/blog/disable-gutenberg-wordpress-editor/#disable-gutenberg-code */

//enque styles and scripts
require get_template_directory().'/inc/setup_theme/onis_register_styles.php';
require get_template_directory().'/inc/setup_theme/onis_register_scripts.php';


//register sidebars
require get_template_directory().'/inc/setup_theme/onis_register_sidebars.php';




/*function _fonts() {
  wp_enqueue_style('googleFonts', '//fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic');
  wp_enqueue_style( 'googleFontsLato', get_template_directory_uri(  ), '/fonts/fonts' );
}
add_action('wp_enqueue_scripts', '_fonts');
*/



/*to give additional classes to nav*/
add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);

function special_nav_class ($classes, $item) {
  if (in_array('current-menu-item', $classes) ){
    $classes[] = 'active ';
  }
  return $classes;
}

/*

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/customizer/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer/customizer.php';







/* customize admin area*/
require get_template_directory().'/inc/admin-area/admin-functions.php';
