/*let svgTitleHome = window.document.getElementById('titleHome');



let svgBetukArray = window.document.querySelectorAll('#titleHome path');


/*for (let i = 0; i < svgBetukArray.length; i++) {*/
/*if(svgBetukArray[i].parentElement==svgTitleHome)*/
/*for(let i in svgBetukArray){
    console.log(typeof(svgBetukArray[i].entries));
         console.log('betuk:${i} hossz:  ${svgBetukArray[i].getTotalLength()}');
}
let betu1 = window.document.querySelector('#betu1');
console.log('betu1 hossz: ${betu1.getAttribute}');*/