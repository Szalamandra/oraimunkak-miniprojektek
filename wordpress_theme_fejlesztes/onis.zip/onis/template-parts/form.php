<form action="" class="formAlak" method="post"
                >
                   
                        <legend>Ha bármi kérdése van:</legend>
                        
                        <div class="form-control failed">
                            <label>Név*</label>
                            <input type="text" id="nev" placeholder="Tündér Kata" name="name">
                            <i class="far fa-smile-wink"></i>
                            <i class="fas fa-frown-open"></i>
                            <p class="hibaUzi">Kérem adja meg a nevét!</p>
                        </div>
                        <div class="form-control">
                            <label>Email* </label>
                            <input type="text" id="email" placeholder="tunderKata88@mail.com" name="email" class="formInput">
                            <i class="far fa-smile-wink"></i>
                            <i class="fas fa-frown-open"></i>
                            <p class="hibaUzi">Kérem valós emailcímet adjon meg!</p>
                        </div>
                            
                        <div class="form-control">
                            <label for="textArea">Üzenet:</label>
                            <textarea id="textArea" name="message" placeholder="Üzenet" required></textarea></div>

                
                    <div class="form-control">
                        <div><input type="submit" id="gomb" value="Küldés" class="submitGomb"> </div>
                        </div>
                   

                </form>