<?php
/**
 * Template Name: Front page template
 *
 * @package onis
 */


get_header('frontpage');

?>

	<div id="primaryPage" class="no-sidebar">
		<main id="front_main" class="no-sidebar">
			
    
        
				
				<?php
				if ( have_posts() ) :
					while ( have_posts() ) : the_post();

						get_template_part( 'template-parts/content', 'page' );

					endwhile;
					?>

				<?php

				else :

					get_template_part( 'template-parts/content-none' );

				endif;

				?>
            
            
            <?php get_template_part('template-parts/form');
            ?>
		</main>
	</div> <!--#primaryPage-->

<?php
get_footer();