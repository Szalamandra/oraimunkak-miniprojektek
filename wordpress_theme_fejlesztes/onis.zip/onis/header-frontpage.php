<?php
/**
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package onis
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>"> <!-- ngives us the utf8 charset or whatever we need. -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>   <!-- need this for later hooks. -->
</head>

<body> <!--it gives you place for later links as analitics etc...-->
<?php               
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
}
?>
<div id="frontPage" class="no-sidebar">
	
	<header id="fronthead" class="site-header">
		<!--<div class="site-branding">-->
			<?php
			/*if ( is_front_page() && !is_home() ) :
				?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1><!--This gives me the exact title of the page, helps for google analitics etc... -->
				<?php
			else :
				?>
				<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
				<?php
			endif;
			$_description = get_bloginfo( 'description', 'display' );
			if ( $_description || is_customize_preview() ) :
				?>
				<p class="site-description"><?php echo $_description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			<?php endif; ?>
		</div><!-- .site-branding -->
*/?>
		<nav id="frontpage-site-navigation" class="site-navigation">
			<!--<div id="frontpage_logo"><?php /*the_custom_logo();*/?></div>--> 
			
		<div class="homeMenuDiv">
			<?php
			wp_nav_menu(
			
				array('theme_location' => 'primary_menu_left',
					'menu_id'        => 'primary-menu-l'),
			);?>	
		</div> <!--.homeMenuDiv-->
		<div class="homeMenuDiv">
			<?php wp_nav_menu(
				
				array('theme_location' => 'primary_menu_right',
					'menu_id'        => 'primary-menu-r')
			);?>
		</div> <!--.homeMenuDiv-->
		<div class="homeMenuDiv site-navigation" id="site-navigation">
			<button id="hamburgerButton" class="menu-toggle" aria-controls="menu-mobil-home" aria-expanded="false"><i class="fas fa-bars">
		</i></button>
		<?php
			wp_nav_menu(
				array(
					'theme_location' => 'menu_mobil_home',
					'menu_id'        => 'menu-mobil-home',
					'container_id'         => 'menu-mobil-home',
					'container_class'      => 'menu',
					'menu_class'           => 'nav-menu',
					
				)
		); /*-!wp-nav-menu menu-mobil-home*/
		?></div> <!--.homeMenuDiv-->
		<div class="homeMenuDiv"><button id="calendarButton" class="" aria-expanded="false"><i class="fas fa-calendar-alt"></i></button></div>
		</nav><!-- #site-navigation -->
	</header><!-- #site-header-->